$(document).ready(function(){
    let persian_numbers = document.querySelectorAll(".container *")
    persian_numbers.forEach(function (e){
        traverse(e)
    })
    $(".slider").slick({
        autoplay: false,
        rtl: true,
        infinite: false,
        slidesToShow: 4,
        responsive: [{
            breakpoint: 400,
            settings: {
                slidesToShow: 1,
                infinite: true,
                dots: true,
            }
        },
        {
            breakpoint: 700,
            settings: {
                slidesToShow: 2,
                infinite: true,
                dots: true,
            }
        }]
    });
    $(".slider-2").slick({
        autoplay: false,
        rtl: true,
        slidesToShow: 5,
        responsive: [{
            breakpoint: 400,
            settings: {
                slidesToShow: 1,
                infinite: true,
                dots: true,
                centerMode: true,
                centerPadding: "30px",
            }
        },
            {
                breakpoint: 700,
                settings: {
                    slidesToShow: 2,
                    infinite: true,
                    dots: true,
                }
            }]
    });

    let product_items = document.querySelectorAll(".section-2 .item")
    let filter_items = document.querySelectorAll(".filter-item")

    let active_item = document.querySelector(".filter-item.active").getAttribute("filter")
    product_items.forEach(function(e){
        if(e.getAttribute("item") != active_item){
            hiddenProduct(e)
        }
    })

    filter_items.forEach(function(e){
        e.addEventListener("click", function(){
            let clicked_filter = e.getAttribute("filter")
            resetFilter(filter_items)
            activateFilter(e)
            product_items.forEach(function(b){
                b.classList.remove("hidden")
                if(b.getAttribute("item") != clicked_filter){
                    hiddenProduct(b)
                }
            })
        })
    })
})
persian={0:'۰',1:'۱',2:'۲',3:'۳',4:'۴',5:'۵',6:'۶',7:'۷',8:'۸',9:'۹'};
function traverse(element){
    if(element.nodeType==3){
        var list=element.data.match(/[0-9]/g);
        if(list!=null && list.length!=0){
            for(var i=0;i<list.length;i++)
                element.data=element.data.replace(list[i],persian[list[i]]);
        }
    }
    for(var i=0;i<element.childNodes.length;i++){
        traverse(element.childNodes[i]);
    }
}

function hiddenProduct(e){
    e.classList.add("hidden")
}

function activateFilter(e){
    e.classList.add("active")
}

function resetFilter(filters){
    filters.forEach(function(e){
        e.classList.remove("active")
    })
}
